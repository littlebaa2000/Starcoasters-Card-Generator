INSTALATION INSTRUCTIONS
1. Extract this zip folder to a destination of your choice.
2. Inside the folder you just extracted will be "Starcoasters Card Generator.exe", run it or make a shortcut as you wish
3. When you first start the program it will claim that the database has been destroyed, do not worry as the program will generate its own database
for you and as such unless you delete the database (.db) file it creates you shouldn't see this message again.

LISCENCE
Feel free to redistribute, modify and reverse engineer this code as you see fit however you may not for any reason offer this code, redistributed or modified, in exchange for
money or other commodities. If you reverse engineer anything go nuts but a note in the credits as having provided some inspiration would be appreciated but not required
as would a link to whatever you make with it.

CREDITS
Testers(so far)
Neo-Eyes GameboyGeek (myself)
Draco2000AR